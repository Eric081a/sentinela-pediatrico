const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url,body,method){const o={method:method||(body?"POST":"GET"),headers:{"Content-Type":"application/json"}};
 if(body)o.body=JSON.stringify(body);let r;try{r=await fetch(url,o)}catch{throw new Error("Sem conexão com o servidor.")}
 const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.erro||"Erro "+r.status);return d}
const MENU={atendimento:["atendimento.html","Recepção"],triagem:["triagem.html","Triagem"],medico:["medico.html","Pediatra"],medicacoes:["medicacoes.html","Prescrições"],almoxarifado:["almoxarifado.html","Farmácia"],admin:["admin.html","Admin"]};
const ACESSO={atendimento:["atendimento"],triagem:["triagem"],medico:["medico","medicacoes"],almoxarifado:["almoxarifado","medicacoes"],admin:Object.keys(MENU)};
const HOME=Object.fromEntries(Object.entries(MENU).map(([k,v])=>[k,v[0]]));
function guard(pagina){const u=JSON.parse(sessionStorage.getItem("u")||"null");
 if(!u||!(ACESSO[u.tipo]||[]).includes(pagina)){location.href="index.html";return}
 document.body.insertAdjacentHTML("afterbegin",`<nav><b>🧸 Sentinela Pediatria</b>${ACESSO[u.tipo].map(k=>`<a href="${MENU[k][0]}"${k===pagina?' class="on"':""}>${MENU[k][1]}</a>`).join("")}<a href="#" id="sair">Sair (${esc(u.usuario)})</a></nav>`);
 $("#sair").onclick=e=>{e.preventDefault();sessionStorage.removeItem("u");location.href="index.html"}}
function toast(m,erro){const t=document.createElement("div");t.className="toast"+(erro?" err":"");t.textContent=m;document.body.append(t);setTimeout(()=>t.remove(),3500)}
