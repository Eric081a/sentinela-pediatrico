const express=require("express"),fs=require("fs"),path=require("path"),cors=require("cors"),crypto=require("crypto");
const Ped=require("../frontend/js/pediatria.js");
const app=express();app.use(express.json({limit:"1mb"}));app.use(cors());
app.use(express.static(path.join(__dirname,"../frontend")));

let DB=path.join(__dirname,"db.json");
if(process.env.VERCEL){const t="/tmp/db.json";if(!fs.existsSync(t))fs.copyFileSync(DB,t);DB=t} // Vercel: disco temporário
const hash=s=>{const sal=crypto.randomBytes(8).toString("hex");return sal+":"+crypto.scryptSync(s,sal,32).toString("hex")};
const confere=(s,h)=>{if(!h.includes(":"))return s===h;const[sal,k]=h.split(":");return crypto.timingSafeEqual(crypto.scryptSync(s,sal,32),Buffer.from(k,"hex"))};
const gravar=d=>fs.writeFileSync(DB,JSON.stringify(d,null,2));
function ler(){const d=JSON.parse(fs.readFileSync(DB,"utf8"));let mud=false;
 for(const k of["usuarios","pacientes","triagens","consultas","chamadas","estoque","entradas","altas"])if(!Array.isArray(d[k]))d[k]=[];
 d.usuarios.forEach(u=>{if(!u.senha.includes(":")){u.senha=hash(u.senha);mud=true}}); // senhas antigas em texto puro -> hash
 if(mud)gravar(d);return d}
const rota=fn=>(q,s)=>{try{fn(q,s)}catch(e){console.error(e);s.status(500).json({erro:"Erro interno do servidor."})}};
const bad=(s,m,c=400)=>s.status(c).json({erro:m});
const txt=v=>String(v??"").trim();
const SETORES=["atendimento","triagem","medico","almoxarifado","admin"];

/* ---------- usuários ---------- */
app.post("/login",rota((q,s)=>{const u=ler().usuarios.find(x=>x.usuario===q.body.usuario);
 if(!u||typeof q.body.senha!=="string"||!confere(q.body.senha,u.senha))return bad(s,"Usuário ou senha inválidos.",401);
 s.json({usuario:u.usuario,tipo:u.tipo})}));
// Acesso rápido ao painel administrativo por senha mestra.
app.post("/admin/acesso",rota((q,s)=>{
 const senha=String(q.body.senha??"");
 const senhaAdmin=process.env.ADMIN_PASSWORD||"123";
 if(senha!==senhaAdmin)return bad(s,"Senha administrativa incorreta.",401);
 s.json({usuario:"Administrador",tipo:"admin"});
}));
app.get("/usuarios",rota((q,s)=>s.json(ler().usuarios.map(({usuario,tipo})=>({usuario,tipo})))));
app.post(["/usuario","/usuarios"],rota((q,s)=>{const usuario=txt(q.body.usuario),senha=txt(q.body.senha),tipo=txt(q.body.tipo);
 if(!usuario||!senha||!SETORES.includes(tipo))return bad(s,"Preencha usuário, senha e setor válido.");
 const d=ler();if(d.usuarios.some(u=>u.usuario.toLowerCase()===usuario.toLowerCase()))return bad(s,"Esse usuário já está cadastrado.",409);
 d.usuarios.push({usuario,senha:hash(senha),tipo});gravar(d);s.status(201).json({mensagem:"Usuário cadastrado com sucesso!"})}));
app.put("/usuarios/:u",rota((q,s)=>{const d=ler(),i=d.usuarios.findIndex(u=>u.usuario.toLowerCase()===q.params.u.toLowerCase());
 if(i<0)return bad(s,"Usuário não encontrado.",404);const nome=txt(q.body.usuario),tipo=txt(q.body.tipo);
 if(!nome||!SETORES.includes(tipo))return bad(s,"Informe usuário e setor válidos.");
 if(d.usuarios.some((u,j)=>j!==i&&u.usuario.toLowerCase()===nome.toLowerCase()))return bad(s,"Já existe outro usuário com esse nome.",409);
 Object.assign(d.usuarios[i],{usuario:nome,tipo});if(txt(q.body.senha))d.usuarios[i].senha=hash(q.body.senha);
 gravar(d);s.json({mensagem:"Usuário atualizado com sucesso!"})}));
app.delete("/usuarios/:u",rota((q,s)=>{const d=ler(),i=d.usuarios.findIndex(u=>u.usuario.toLowerCase()===q.params.u.toLowerCase());
 if(i<0)return bad(s,"Usuário não encontrado.",404);
 if(d.usuarios[i].tipo==="admin"&&d.usuarios.filter(u=>u.tipo==="admin").length<2)return bad(s,"Não é possível excluir o único administrador.");
 d.usuarios.splice(i,1);gravar(d);s.json({mensagem:"Usuário excluído com sucesso!"})}));

/* ---------- recepção (cadastro da criança + responsável) ---------- */
app.post("/atendimento",rota((q,s)=>{const b=q.body,nome=txt(b.nome),i=Ped.idade(b.nascimento);
 if(!nome)return bad(s,"Informe o nome da criança.");if(!i)return bad(s,"Data de nascimento inválida.");
 if(!txt(b.responsavel))return bad(s,"Informe o nome do responsável.");
 const d=ler(),p={id:Date.now(),nome,nascimento:b.nascimento,sexo:txt(b.sexo),cpf:txt(b.cpf),responsavel:txt(b.responsavel),telefone:txt(b.telefone),tipo:txt(b.tipo)||"SUS",status:"triagem",createdAt:new Date()};
 d.pacientes.push(p);gravar(d);s.status(201).json(p)}));
app.get("/fila-triagem",rota((q,s)=>{const d=ler();
 s.json(d.pacientes.filter(p=>p.status==="triagem").map(p=>{const i=Ped.idade(p.nascimento)||{meses:0,texto:""};return{...p,meses:i.meses,idadeTexto:i.texto}}))}));

/* ---------- triagem (classificação de risco calculada no servidor) ---------- */
const num=v=>v===""||v==null||isNaN(v)?null:Number(v);
app.post("/triagem",rota((q,s)=>{const b=q.body,d=ler(),p=d.pacientes.find(x=>x.id===Number(b.pacienteId));
 if(!p)return bad(s,"Paciente não encontrado.",404);
 const v={temp:num(b.temperatura),fc:num(b.fc),fr:num(b.fr),spo2:num(b.spo2),peso:num(b.peso)};
 if(!v.peso||v.peso<0.3||v.peso>150)return bad(s,"Informe um peso válido (kg).");
 if(v.temp!=null&&(v.temp<30||v.temp>43))return bad(s,"Temperatura inválida.");
 if(v.spo2!=null&&(v.spo2<30||v.spo2>100))return bad(s,"SpO₂ inválida.");
 const sinais=(Array.isArray(b.sinais)?b.sinais:[]).filter(k=>Ped.SINAIS[k]);
 const c=Ped.classificar({meses:Ped.idade(p.nascimento).meses,...v,sinais});
 const t={id:Date.now(),pacienteId:p.id,nome:p.nome,nascimento:p.nascimento,sintoma:txt(b.sintoma),temperatura:v.temp,fc:v.fc,fr:v.fr,spo2:v.spo2,peso:v.peso,
  alergia:txt(b.alergia),observacao:txt(b.observacao),sinais,risco:c.risco,motivos:c.motivos,status:"aguardando_medico",createdAt:new Date()};
 d.triagens.push(t);p.status="aguardando_medico";gravar(d);s.status(201).json(t)}));
const ORDEM={vermelho:0,laranja:1,amarelo:2,verde:3,azul:4};
const espera=t=>Math.max(0,Math.round((Date.now()-new Date(t))/6e4));
app.get("/triagens",rota((q,s)=>s.json(ler().triagens.filter(t=>t.status==="aguardando_medico")
 .map(t=>({...t,idadeTexto:(Ped.idade(t.nascimento)||{}).texto||"",espera:espera(t.createdAt),alvo:Ped.ALVO[t.risco]}))
 .sort((a,b)=>(ORDEM[a.risco]??3)-(ORDEM[b.risco]??3)||new Date(a.createdAt)-new Date(b.createdAt)))));

/* ---------- painel de TV ---------- */
const nomeTV=n=>{const p=txt(n).split(/\s+/).filter(Boolean);if(!p.length)return"Paciente";const c=x=>x[0].toUpperCase()+x.slice(1).toLowerCase();
 return p.length===1?c(p[0]):c(p[0])+" "+p[p.length-1][0].toUpperCase()+"."};
app.post("/chamar",rota((q,s)=>{if(!txt(q.body.nome))return bad(s,"Informe o nome do paciente.");
 const d=ler(),t=d.triagens.find(x=>x.id===Number(q.body.id));if(t)t.status="em_atendimento";
 const c={id:Date.now(),nome:txt(q.body.nome),destino:txt(q.body.destino)||"Consultório Pediátrico",createdAt:new Date()};
 d.chamadas=[...d.chamadas,c].slice(-50);gravar(d);s.status(201).json(c)}));
app.get("/tv-dados",rota((q,s)=>{const d=ler(),lim=Date.now()-864e5;
 const fila=d.triagens.filter(t=>t.status==="aguardando_medico"&&new Date(t.createdAt)>=lim)
  .sort((a,b)=>(ORDEM[a.risco]??3)-(ORDEM[b.risco]??3)||new Date(a.createdAt)-new Date(b.createdAt))
  .map(t=>({nome:nomeTV(t.nome),risco:t.risco||"verde",espera:espera(t.createdAt)}));
 const rec=d.chamadas.slice().reverse().map(c=>({id:c.id,nome:nomeTV(c.nome),destino:c.destino,createdAt:c.createdAt}));
 s.json({chamadaAtual:rec[0]||null,historico:rec.slice(1,4),fila})}));

/* ---------- consulta e prescrição ---------- */
app.get("/lista-medicacoes",(q,s)=>s.json(Ped.FORM));
app.post("/consulta",rota((q,s)=>{const b=q.body,d=ler();if(!txt(b.paciente))return bad(s,"Selecione um paciente.");
 const pr=(Array.isArray(b.prescricoes)?b.prescricoes:[]).map(x=>({nome:txt(x.nome),texto:txt(x.texto)}));
 const c={id:Date.now(),pacienteId:b.pacienteId||null,paciente:txt(b.paciente),diagnostico:txt(b.diagnostico),prescricoes:pr,medicacao:pr.map(x=>x.texto).join("; "),obs:txt(b.obs),createdAt:new Date()};
 d.consultas.push(c);const t=d.triagens.find(x=>x.id===Number(b.triagemId));if(t)t.status="finalizado";
 const p=d.pacientes.find(x=>x.id===Number(b.pacienteId));if(p)p.status="aguardando_alta";gravar(d);s.status(201).json(c)}));
app.get(["/medicacoes","/consultas"],rota((q,s)=>s.json(ler().consultas.slice().reverse())));



/* ---------- alta e registro de saída pediátrica ---------- */
app.get("/pacientes-alta",rota((q,s)=>{
 const d=ler();
 // Compatibilidade: na versão anterior, a consulta concluída já marcava o paciente como "finalizado".
 const lista=d.pacientes.filter(p=>d.consultas.some(c=>Number(c.pacienteId)===Number(p.id)) &&
   (p.status==="aguardando_alta" || (p.status==="finalizado" && !d.altas.some(a=>Number(a.pacienteId)===Number(p.id)))))
  .map(p=>{if(p.status==="finalizado")p.status="aguardando_alta";
   const triagem=d.triagens.filter(t=>Number(t.pacienteId)===Number(p.id)).slice(-1)[0]||null;
   return {...p,triagem,consulta:d.consultas.filter(c=>Number(c.pacienteId)===Number(p.id)).slice(-1)[0]};});
 gravar(d);s.json(lista);
}));
app.get("/altas",rota((q,s)=>s.json(ler().altas.slice().reverse())));
app.post("/alta",rota((q,s)=>{
 const b=q.body,d=ler(),p=d.pacientes.find(x=>x.id===Number(b.pacienteId));
 if(!p)return bad(s,"Paciente não encontrado.",404);
 if(p.status!=="aguardando_alta")return bad(s,"Este paciente não está aguardando encerramento.",409);
 if(!d.consultas.some(c=>Number(c.pacienteId)===Number(p.id)))return bad(s,"É necessário existir uma consulta registrada antes da alta.",409);
 const tipos=["Alta médica","Transferência","Alta a pedido do responsável","Saída sem autorização (registro administrativo)"];
 const tipo=txt(b.tipo),responsavel=txt(b.responsavel),profissional=txt(b.profissional),registro=txt(b.registro);
 if(!tipos.includes(tipo))return bad(s,"Selecione um tipo de saída válido.");
 if(!responsavel)return bad(s,"Informe o responsável que acompanha a criança.");
 if(!profissional||!registro)return bad(s,"Informe o profissional responsável e seu registro profissional.");
 if(tipo==="Transferência"&&!txt(b.destino))return bad(s,"Informe o serviço de destino da transferência.");
 if(tipo==="Alta a pedido do responsável"&&!b.termoResponsavel)return bad(s,"Registre a confirmação do termo de solicitação do responsável.");
 if(tipo==="Saída sem autorização (registro administrativo)"&&!b.registroOcorrencia)return bad(s,"Confirme o registro da ocorrência com a equipe responsável.");
 const checklist={identificacao:!!b.identificacao,documentos:!!b.documentos,orientacoes:!!b.orientacoes,pertences:!!b.pertences,acompanhante:!!b.acompanhante};
 if(Object.values(checklist).some(v=>!v))return bad(s,"Conclua todos os itens da lista de conferência antes de registrar a saída.");
 const alta={id:Date.now(),pacienteId:p.id,paciente:p.nome,nascimento:p.nascimento,tipo,responsavel,profissional,registro,destino:txt(b.destino),contatoDestino:txt(b.contatoDestino),orientacoes:txt(b.orientacoesTexto),retorno:txt(b.retorno),observacoes:txt(b.observacoes),checklist,termoResponsavel:!!b.termoResponsavel,registroOcorrencia:!!b.registroOcorrencia,createdAt:new Date().toISOString()};
 d.altas.push(alta);p.status="encerrado";p.dataSaida=alta.createdAt;gravar(d);s.status(201).json(alta);
}));

/* ---------- almoxarifado ---------- */
app.get("/estoque",rota((q,s)=>s.json(ler().estoque)));
app.get("/estoque/entradas",rota((q,s)=>s.json(ler().entradas.slice(-15).reverse())));
app.post("/estoque",rota((q,s)=>{const b=q.body,nome=txt(b.nome),qtd=Number(b.qtd);
 if(!nome||!Number.isInteger(qtd)||qtd<1)return bad(s,"Informe o medicamento e uma quantidade inteira maior que zero.");
 const d=ler();let it=d.estoque.find(i=>i.nome.toLowerCase()===nome.toLowerCase());const novo=!it;
 if(novo){it={id:Date.now(),nome,unidade:txt(b.unidade)||"unidade",categoria:txt(b.categoria)||"Geral",quantidade:0};d.estoque.push(it)}
 it.quantidade+=qtd;if(txt(b.validade))it.validade=txt(b.validade);
 d.entradas.push({id:Date.now(),nome:it.nome,qtd,tipo:novo?"novo":"reposição",obs:txt(b.obs),createdAt:new Date()});
 gravar(d);s.status(201).json(it)}));

if(require.main===module)app.listen(process.env.PORT||3000,()=>console.log("🧸 Sentinela Pediatria em http://localhost:"+(process.env.PORT||3000)));
module.exports=app;
