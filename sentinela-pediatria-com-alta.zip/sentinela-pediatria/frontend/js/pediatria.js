/* Regras pediátricas compartilhadas (servidor + navegador).
   ATENÇÃO: valores de referência (PALS/AIDPI/Manchester/bulas) - validar com o protocolo do hospital. */
(function(r,f){typeof module==="object"&&module.exports?module.exports=f():r.Pediatria=f()})(this,function(){
const ORD=["azul","verde","amarelo","laranja","vermelho"];
const ALVO={vermelho:0,laranja:10,amarelo:60,verde:120,azul:240}; // minutos (Manchester)
const SINAIS={
 inconsciente:["vermelho","Inconsciente / não responde"],convulsao:["vermelho","Convulsão em andamento"],
 resp_grave:["vermelho","Desconforto respiratório grave (tiragem, gemência, apneia)"],cianose:["vermelho","Cianose"],
 choque:["vermelho","Sinais de choque (pele fria, pulso fraco, enchimento capilar > 3 s)"],
 letargia:["laranja","Letargia / prostração / irritabilidade extrema"],petequias:["laranja","Petéquias / manchas que não desaparecem à compressão"],
 rigidez:["laranja","Rigidez de nuca"],desidratacao:["laranja","Sinais de desidratação (olhos fundos, sem lágrimas, sem urina há +8 h)"],
 recusa:["laranja","Recusa de líquidos / não consegue mamar"],dengue:["laranja","Sinal de alarme de dengue (dor abdominal intensa, sangramento de mucosa, vômitos persistentes)"],
 convulsao24:["laranja","Convulsão nas últimas 24 h"],vomitos:["amarelo","Vômitos repetidos"],dor:["amarelo","Dor intensa"]};
const FAIXAS=[[1,205,60],[12,180,50],[36,140,40],[72,120,40],[144,118,25],[1e5,100,20]]; // [até (meses), FC máx, FR máx]
function idade(nasc,ref=new Date()){const n=new Date(nasc);if(isNaN(n)||n>ref)return null;
 let m=(ref.getFullYear()-n.getFullYear())*12+ref.getMonth()-n.getMonth();if(ref.getDate()<n.getDate())m--;
 const a=Math.floor(m/12),r=m%12,d=Math.floor((ref-n)/864e5);
 return{meses:m,texto:m<1?d+(d===1?" dia":" dias"):m<24?m+(m===1?" mês":" meses"):a+" anos"+(r?" e "+r+" m":"")}}
function classificar(d){const mot=[];let n=1;const up=(l,t)=>{mot.push(t);n=Math.max(n,ORD.indexOf(l))};
 const meses=d.meses||0,[,fcM,frM]=FAIXAS.find(x=>meses<x[0]),ok=v=>v!=null&&!isNaN(v);
 (d.sinais||[]).forEach(k=>SINAIS[k]&&up(SINAIS[k][0],SINAIS[k][1]));
 if(ok(d.temp)){const t=d.temp;
  if(meses<3&&t>=38)up(meses<1?"vermelho":"laranja","Febre ≥ 38 °C em menor de 3 meses");
  else if(t>=40)up("laranja","Febre ≥ 40 °C");else if(t>=39)up("amarelo","Febre ≥ 39 °C");else if(t>=37.8)up("verde","Febre");
  if(meses<3&&t<35.5)up("laranja","Hipotermia em menor de 3 meses")}
 if(ok(d.spo2)){if(d.spo2<90)up("vermelho","SpO₂ < 90%");else if(d.spo2<92)up("laranja","SpO₂ < 92%");else if(d.spo2<95)up("amarelo","SpO₂ < 95%")}
 if(ok(d.fc)&&d.fc>fcM)up(d.fc>fcM*1.25?"laranja":"amarelo","FC "+d.fc+" acima do esperado para a idade (máx. ~"+fcM+")");
 if(ok(d.fr)&&d.fr>frM)up(d.fr>frM*1.25?"laranja":"amarelo","FR "+d.fr+" acima do esperado para a idade (máx. ~"+frM+")");
 return{risco:ORD[n],motivos:mot,alvoMin:ALVO[ORD[n]]}}
/* Formulário: modo "dose" = mg/kg por dose; "dia" = mg/kg/dia dividido em "vezes". conc em mg/mL */
const FORM=[
 {id:"paracetamol",nome:"Paracetamol",modo:"dose",min:10,max:15,pad:10,vezes:4,intervalo:"6/6 h",conc:200,apres:"gotas 200 mg/mL",maxDiaKg:75},
 {id:"dipirona",nome:"Dipirona",modo:"dose",min:10,max:25,pad:15,vezes:4,intervalo:"6/6 h",conc:500,apres:"gotas 500 mg/mL",minMeses:3,minKg:5},
 {id:"ibuprofeno",nome:"Ibuprofeno",modo:"dose",min:5,max:10,pad:10,vezes:3,intervalo:"8/8 h",conc:50,apres:"gotas 50 mg/mL",minMeses:6,maxDiaKg:40,nota:"Evitar se houver suspeita de dengue."},
 {id:"amoxicilina",nome:"Amoxicilina",modo:"dia",min:25,max:50,pad:50,vezes:3,intervalo:"8/8 h",conc:50,apres:"suspensão 250 mg/5 mL"},
 {id:"azitromicina",nome:"Azitromicina",modo:"dose",min:10,max:10,pad:10,vezes:1,intervalo:"1x ao dia",conc:40,apres:"suspensão 200 mg/5 mL",maxDose:500},
 {id:"ondansetrona",nome:"Ondansetrona",modo:"dose",min:0.1,max:0.15,pad:0.15,vezes:3,intervalo:"8/8 h",conc:0.8,apres:"solução 4 mg/5 mL",maxDose:8,minMeses:6},
 {id:"prednisolona",nome:"Prednisolona",modo:"dia",min:1,max:2,pad:1,vezes:1,intervalo:"1x ao dia",conc:3,apres:"solução 3 mg/mL",maxDose:40}];
function dose(f,kg,meses,mgkg){if(!(kg>0))return{erro:"Informe o peso."};const a=[];mgkg=mgkg>0?mgkg:f.pad;
 if(f.minMeses&&meses<f.minMeses)a.push("Não recomendado abaixo de "+f.minMeses+" meses.");
 if(f.minKg&&kg<f.minKg)a.push("Não recomendado abaixo de "+f.minKg+" kg.");
 if(mgkg<f.min||mgkg>f.max)a.push("Dose fora da faixa usual ("+f.min+"–"+f.max+" mg/kg"+(f.modo==="dia"?"/dia":"/dose")+").");
 let mg=f.modo==="dia"?mgkg*kg/f.vezes:mgkg*kg;
 if(f.maxDose&&mg>f.maxDose){mg=f.maxDose;a.push("Limitado à dose máxima de "+f.maxDose+" mg.")}
 if(f.maxDiaKg&&mg*f.vezes/kg>f.maxDiaKg)a.push("Ultrapassa "+f.maxDiaKg+" mg/kg/dia.");
 return{mg:+mg.toFixed(1),ml:+(mg/f.conc).toFixed(1),vezes:f.vezes,intervalo:f.intervalo,alertas:a}}
function manutencao(kg){const d=kg<=10?kg*100:kg<=20?1000+(kg-10)*50:1500+(kg-20)*20;return{dia:Math.round(d),hora:+(d/24).toFixed(1)}}
return{ORD,ALVO,SINAIS,FORM,idade,classificar,dose,manutencao}});
