/* =====================================================
   banco.js — leitura e gravação do arquivo db.json
   + funções de senha (hash com sal).
   ===================================================== */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

/* ---------- Onde o banco fica salvo ---------- */

let ARQUIVO = path.join(__dirname, "db.json");

// Na Vercel só podemos escrever em /tmp (disco temporário).
// Atenção: lá os dados são apagados de tempos em tempos.
if (process.env.VERCEL) {
  const temporario = "/tmp/db.json";
  if (!fs.existsSync(temporario)) {
    fs.copyFileSync(ARQUIVO, temporario);
  }
  ARQUIVO = temporario;
}

/* ---------- Listas que sempre precisam existir no banco ---------- */

const COLECOES = [
  // sistema hospitalar
  "usuarios",
  "pacientes",
  "triagens",
  "consultas",
  "chamadas",
  "estoque",
  "entradas",
  "altas",
  // cuidado emocional e bem-estar
  "encaminhamentos",
  "sessoesPsicologia",
  "avaliacoesPsiquiatria",
  "humores",
  "participacoes"
];

/* ---------- Senhas ---------- */

// Transforma "123" em "sal:hash" (nunca guardamos a senha pura).
function gerarHash(senha) {
  const sal = crypto.randomBytes(8).toString("hex");
  const chave = crypto.scryptSync(senha, sal, 32).toString("hex");
  return sal + ":" + chave;
}

// Confere se a senha digitada corresponde ao que está guardado.
function conferirSenha(senha, guardada) {
  // Compatibilidade: senha antiga ainda em texto puro.
  if (!guardada.includes(":")) {
    return senha === guardada;
  }

  const [sal, chave] = guardada.split(":");
  const calculada = crypto.scryptSync(senha, sal, 32);
  return crypto.timingSafeEqual(calculada, Buffer.from(chave, "hex"));
}

/* ---------- Leitura e gravação ---------- */

function gravar(dados) {
  fs.writeFileSync(ARQUIVO, JSON.stringify(dados, null, 2));
}

function ler() {
  const dados = JSON.parse(fs.readFileSync(ARQUIVO, "utf8"));
  let precisaGravar = false;

  // Garante que toda lista exista (bancos antigos não tinham as novas).
  for (const nome of COLECOES) {
    if (!Array.isArray(dados[nome])) {
      dados[nome] = [];
    }
  }

  // Senhas antigas em texto puro viram hash automaticamente.
  for (const usuario of dados.usuarios) {
    if (!usuario.senha.includes(":")) {
      usuario.senha = gerarHash(usuario.senha);
      precisaGravar = true;
    }
  }

  if (precisaGravar) {
    gravar(dados);
  }

  return dados;
}

module.exports = { ler, gravar, gerarHash, conferirSenha };
