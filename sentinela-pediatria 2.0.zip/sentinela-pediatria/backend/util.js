/* =====================================================
   util.js — funções pequenas usadas por várias rotas
   ===================================================== */

// Converte qualquer valor em texto sem espaços nas pontas.
//   txt("  oi ")  -> "oi"
//   txt(null)     -> ""
const txt = valor => String(valor ?? "").trim();

// Converte em número; vazio ou inválido vira null.
const num = valor =>
  valor === "" || valor == null || isNaN(valor) ? null : Number(valor);

// Responde com erro no formato { erro: "mensagem" }.
const bad = (resposta, mensagem, codigo = 400) =>
  resposta.status(codigo).json({ erro: mensagem });

// Envolve uma rota para que um erro inesperado não derrube o servidor.
const rota = funcao => (req, res) => {
  try {
    funcao(req, res);
  } catch (erro) {
    console.error(erro);
    res.status(500).json({ erro: "Erro interno do servidor." });
  }
};

// Gera um id único e sempre crescente (Date.now() puro pode repetir
// quando dois registros são criados no mesmo milissegundo).
let ultimoId = 0;
function novoId() {
  ultimoId = Math.max(Date.now(), ultimoId + 1);
  return ultimoId;
}

// Lê um número inteiro opcional dentro de um intervalo.
//   vazio            -> null  (campo não preenchido)
//   válido           -> o número
//   inválido/fora    -> undefined (use para devolver erro)
function inteiroEntre(valor, minimo, maximo) {
  if (valor === "" || valor == null) return null;

  const n = Number(valor);
  const valido = Number.isInteger(n) && n >= minimo && n <= maximo;
  return valido ? n : undefined;
}

module.exports = { txt, num, bad, rota, novoId, inteiroEntre };
