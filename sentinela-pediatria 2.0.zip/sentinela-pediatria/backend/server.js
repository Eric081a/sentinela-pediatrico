/* =====================================================
   server.js — servidor principal do Sentinela Pediatria

   Organização deste arquivo:
     1. Configuração
     2. Usuários e login
     3. Recepção
     4. Triagem
     5. Painel de TV
     6. Consulta e prescrição
     7. Alta e saída
     8. Almoxarifado (farmácia)
     9. Cuidado emocional (arquivo rotas-bemestar.js)
   ===================================================== */

const express = require("express");
const path = require("path");
const cors = require("cors");

const Ped = require("../frontend/js/pediatria.js");
const { ler, gravar, gerarHash, conferirSenha } = require("./banco");
const { txt, num, bad, rota, novoId } = require("./util");
const rotasBemestar = require("./rotas-bemestar");

/* =====================================================
   1. CONFIGURAÇÃO
   ===================================================== */
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(cors());
app.use(express.static(path.join(__dirname, "../frontend")));

// Setores (perfis) que um usuário pode ter.
const SETORES = [
  "atendimento",
  "triagem",
  "medico",
  "psicologia",
  "psiquiatria",
  "bemestar",
  "almoxarifado",
  "admin"
];

/* =====================================================
   2. USUÁRIOS E LOGIN
   ===================================================== */

app.post("/login", rota((req, res) => {
  const usuario = ler().usuarios.find(u => u.usuario === req.body.usuario);

  const senhaValida =
    usuario &&
    typeof req.body.senha === "string" &&
    conferirSenha(req.body.senha, usuario.senha);

  if (!senhaValida) return bad(res, "Usuário ou senha inválidos.", 401);

  res.json({ usuario: usuario.usuario, tipo: usuario.tipo });
}));

// Acesso rápido ao painel administrativo por senha mestra.
app.post("/admin/acesso", rota((req, res) => {
  const senha = String(req.body.senha ?? "");
  const senhaAdmin = process.env.ADMIN_PASSWORD || "123";

  if (senha !== senhaAdmin) return bad(res, "Senha administrativa incorreta.", 401);

  res.json({ usuario: "Administrador", tipo: "admin" });
}));

// Lista usuários (sem senha).
app.get("/usuarios", rota((req, res) => {
  const lista = ler().usuarios.map(({ usuario, tipo }) => ({ usuario, tipo }));
  res.json(lista);
}));

// Cria usuário.
app.post(["/usuario", "/usuarios"], rota((req, res) => {
  const usuario = txt(req.body.usuario);
  const senha = txt(req.body.senha);
  const tipo = txt(req.body.tipo);

  if (!usuario || !senha || !SETORES.includes(tipo)) {
    return bad(res, "Preencha usuário, senha e setor válido.");
  }

  const dados = ler();
  const jaExiste = dados.usuarios.some(u => u.usuario.toLowerCase() === usuario.toLowerCase());
  if (jaExiste) return bad(res, "Esse usuário já está cadastrado.", 409);

  dados.usuarios.push({ usuario, senha: gerarHash(senha), tipo });
  gravar(dados);

  res.status(201).json({ mensagem: "Usuário cadastrado com sucesso!" });
}));

// Edita usuário (a senha só muda se uma nova for enviada).
app.put("/usuarios/:u", rota((req, res) => {
  const dados = ler();
  const indice = dados.usuarios.findIndex(u => u.usuario.toLowerCase() === req.params.u.toLowerCase());
  if (indice < 0) return bad(res, "Usuário não encontrado.", 404);

  const novoNome = txt(req.body.usuario);
  const tipo = txt(req.body.tipo);
  if (!novoNome || !SETORES.includes(tipo)) return bad(res, "Informe usuário e setor válidos.");

  const nomeEmUso = dados.usuarios.some((u, j) =>
    j !== indice && u.usuario.toLowerCase() === novoNome.toLowerCase()
  );
  if (nomeEmUso) return bad(res, "Já existe outro usuário com esse nome.", 409);

  Object.assign(dados.usuarios[indice], { usuario: novoNome, tipo });
  if (txt(req.body.senha)) {
    dados.usuarios[indice].senha = gerarHash(req.body.senha);
  }
  gravar(dados);

  res.json({ mensagem: "Usuário atualizado com sucesso!" });
}));

// Exclui usuário (nunca o único administrador).
app.delete("/usuarios/:u", rota((req, res) => {
  const dados = ler();
  const indice = dados.usuarios.findIndex(u => u.usuario.toLowerCase() === req.params.u.toLowerCase());
  if (indice < 0) return bad(res, "Usuário não encontrado.", 404);

  const ehAdmin = dados.usuarios[indice].tipo === "admin";
  const totalAdmins = dados.usuarios.filter(u => u.tipo === "admin").length;
  if (ehAdmin && totalAdmins < 2) return bad(res, "Não é possível excluir o único administrador.");

  dados.usuarios.splice(indice, 1);
  gravar(dados);

  res.json({ mensagem: "Usuário excluído com sucesso!" });
}));

/* =====================================================
   3. RECEPÇÃO (cadastro da criança + responsável)
   ===================================================== */

app.post("/atendimento", rota((req, res) => {
  const b = req.body;
  const nome = txt(b.nome);
  const idade = Ped.idade(b.nascimento);

  if (!nome) return bad(res, "Informe o nome da criança.");
  if (!idade) return bad(res, "Data de nascimento inválida.");
  if (!txt(b.responsavel)) return bad(res, "Informe o nome do responsável.");

  const paciente = {
    id: novoId(),
    nome,
    nascimento: b.nascimento,
    sexo: txt(b.sexo),
    cpf: txt(b.cpf),
    responsavel: txt(b.responsavel),
    telefone: txt(b.telefone),
    tipo: txt(b.tipo) || "SUS",
    status: "triagem",
    createdAt: new Date()
  };

  const dados = ler();
  dados.pacientes.push(paciente);
  gravar(dados);

  res.status(201).json(paciente);
}));

app.get("/fila-triagem", rota((req, res) => {
  const dados = ler();

  const fila = dados.pacientes
    .filter(p => p.status === "triagem")
    .map(p => {
      const idade = Ped.idade(p.nascimento) || { meses: 0, texto: "" };
      return { ...p, meses: idade.meses, idadeTexto: idade.texto };
    });

  res.json(fila);
}));

/* =====================================================
   4. TRIAGEM (classificação de risco calculada no servidor)
   ===================================================== */

app.post("/triagem", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = dados.pacientes.find(p => p.id === Number(b.pacienteId));
  if (!paciente) return bad(res, "Paciente não encontrado.", 404);

  const vitais = {
    temp: num(b.temperatura),
    fc: num(b.fc),
    fr: num(b.fr),
    spo2: num(b.spo2),
    peso: num(b.peso)
  };

  if (!vitais.peso || vitais.peso < 0.3 || vitais.peso > 150) {
    return bad(res, "Informe um peso válido (kg).");
  }
  if (vitais.temp != null && (vitais.temp < 30 || vitais.temp > 43)) {
    return bad(res, "Temperatura inválida.");
  }
  if (vitais.spo2 != null && (vitais.spo2 < 30 || vitais.spo2 > 100)) {
    return bad(res, "SpO₂ inválida.");
  }

  const sinais = (Array.isArray(b.sinais) ? b.sinais : []).filter(chave => Ped.SINAIS[chave]);

  const classificacao = Ped.classificar({
    meses: Ped.idade(paciente.nascimento).meses,
    ...vitais,
    sinais
  });

  const triagem = {
    id: novoId(),
    pacienteId: paciente.id,
    nome: paciente.nome,
    nascimento: paciente.nascimento,
    sintoma: txt(b.sintoma),
    temperatura: vitais.temp,
    fc: vitais.fc,
    fr: vitais.fr,
    spo2: vitais.spo2,
    peso: vitais.peso,
    alergia: txt(b.alergia),
    observacao: txt(b.observacao),
    sinais,
    risco: classificacao.risco,
    motivos: classificacao.motivos,
    status: "aguardando_medico",
    createdAt: new Date()
  };

  dados.triagens.push(triagem);
  paciente.status = "aguardando_medico";
  gravar(dados);

  res.status(201).json(triagem);
}));

// Ordem de atendimento: do mais grave ao menos grave.
const ORDEM = { vermelho: 0, laranja: 1, amarelo: 2, verde: 3, azul: 4 };

// Minutos que a criança já espera.
const espera = data => Math.max(0, Math.round((Date.now() - new Date(data)) / 6e4));

// Compara duas triagens: mais grave primeiro; empate = quem chegou antes.
const compararGravidade = (a, b) =>
  (ORDEM[a.risco] ?? 3) - (ORDEM[b.risco] ?? 3) ||
  new Date(a.createdAt) - new Date(b.createdAt);

app.get("/triagens", rota((req, res) => {
  const fila = ler().triagens
    .filter(t => t.status === "aguardando_medico")
    .map(t => ({
      ...t,
      idadeTexto: (Ped.idade(t.nascimento) || {}).texto || "",
      espera: espera(t.createdAt),
      alvo: Ped.ALVO[t.risco]
    }))
    .sort(compararGravidade);

  res.json(fila);
}));

/* =====================================================
   5. PAINEL DE TV
   ===================================================== */

// "Maria da Silva" -> "Maria S." (privacidade na tela pública)
function nomeParaTV(nomeCompleto) {
  const partes = txt(nomeCompleto).split(/\s+/).filter(Boolean);
  if (!partes.length) return "Paciente";

  const capitalizar = p => p[0].toUpperCase() + p.slice(1).toLowerCase();
  if (partes.length === 1) return capitalizar(partes[0]);

  const inicialSobrenome = partes[partes.length - 1][0].toUpperCase() + ".";
  return capitalizar(partes[0]) + " " + inicialSobrenome;
}

app.post("/chamar", rota((req, res) => {
  if (!txt(req.body.nome)) return bad(res, "Informe o nome do paciente.");

  const dados = ler();

  const triagem = dados.triagens.find(t => t.id === Number(req.body.id));
  if (triagem) triagem.status = "em_atendimento";

  const chamada = {
    id: novoId(),
    nome: txt(req.body.nome),
    destino: txt(req.body.destino) || "Consultório Pediátrico",
    createdAt: new Date()
  };

  // Guarda apenas as 50 chamadas mais recentes.
  dados.chamadas = [...dados.chamadas, chamada].slice(-50);
  gravar(dados);

  res.status(201).json(chamada);
}));

app.get("/tv-dados", rota((req, res) => {
  const dados = ler();
  const umDiaAtras = Date.now() - 864e5;

  const fila = dados.triagens
    .filter(t => t.status === "aguardando_medico" && new Date(t.createdAt) >= umDiaAtras)
    .sort(compararGravidade)
    .map(t => ({
      nome: nomeParaTV(t.nome),
      risco: t.risco || "verde",
      espera: espera(t.createdAt)
    }));

  const recentes = dados.chamadas
    .slice()
    .reverse()
    .map(c => ({
      id: c.id,
      nome: nomeParaTV(c.nome),
      destino: c.destino,
      createdAt: c.createdAt
    }));

  res.json({
    chamadaAtual: recentes[0] || null,
    historico: recentes.slice(1, 4),
    fila
  });
}));

/* =====================================================
   6. CONSULTA E PRESCRIÇÃO
   ===================================================== */

app.get("/lista-medicacoes", (req, res) => res.json(Ped.FORM));

app.post("/consulta", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  if (!txt(b.paciente)) return bad(res, "Selecione um paciente.");

  const prescricoes = (Array.isArray(b.prescricoes) ? b.prescricoes : [])
    .map(item => ({ nome: txt(item.nome), texto: txt(item.texto) }));

  const consulta = {
    id: novoId(),
    pacienteId: b.pacienteId || null,
    paciente: txt(b.paciente),
    diagnostico: txt(b.diagnostico),
    prescricoes,
    medicacao: prescricoes.map(item => item.texto).join("; "),
    obs: txt(b.obs),
    createdAt: new Date()
  };
  dados.consultas.push(consulta);

  // A triagem termina e a criança passa a aguardar o registro de alta.
  const triagem = dados.triagens.find(t => t.id === Number(b.triagemId));
  if (triagem) triagem.status = "finalizado";

  const paciente = dados.pacientes.find(p => p.id === Number(b.pacienteId));
  if (paciente) paciente.status = "aguardando_alta";

  gravar(dados);
  res.status(201).json(consulta);
}));

app.get(["/medicacoes", "/consultas"], rota((req, res) => {
  res.json(ler().consultas.slice().reverse());
}));

/* =====================================================
   7. ALTA E REGISTRO DE SAÍDA PEDIÁTRICA
   ===================================================== */

app.get("/pacientes-alta", rota((req, res) => {
  const dados = ler();

  const temConsulta = p => dados.consultas.some(c => Number(c.pacienteId) === Number(p.id));
  const jaTemAlta = p => dados.altas.some(a => Number(a.pacienteId) === Number(p.id));

  // Compatibilidade: na versão anterior, a consulta concluída já
  // marcava o paciente como "finalizado".
  const aguardandoAlta = p =>
    p.status === "aguardando_alta" || (p.status === "finalizado" && !jaTemAlta(p));

  const lista = dados.pacientes
    .filter(p => temConsulta(p) && aguardandoAlta(p))
    .map(p => {
      if (p.status === "finalizado") p.status = "aguardando_alta";

      const triagem = dados.triagens
        .filter(t => Number(t.pacienteId) === Number(p.id))
        .slice(-1)[0] || null;

      const consulta = dados.consultas
        .filter(c => Number(c.pacienteId) === Number(p.id))
        .slice(-1)[0];

      return { ...p, triagem, consulta };
    });

  gravar(dados);
  res.json(lista);
}));

app.get("/altas", rota((req, res) => {
  res.json(ler().altas.slice().reverse());
}));

const TIPOS_DE_SAIDA = [
  "Alta médica",
  "Transferência",
  "Alta a pedido do responsável",
  "Saída sem autorização (registro administrativo)"
];

app.post("/alta", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = dados.pacientes.find(p => p.id === Number(b.pacienteId));
  if (!paciente) return bad(res, "Paciente não encontrado.", 404);

  if (paciente.status !== "aguardando_alta") {
    return bad(res, "Este paciente não está aguardando encerramento.", 409);
  }

  const temConsulta = dados.consultas.some(c => Number(c.pacienteId) === Number(paciente.id));
  if (!temConsulta) {
    return bad(res, "É necessário existir uma consulta registrada antes da alta.", 409);
  }

  const tipo = txt(b.tipo);
  const responsavel = txt(b.responsavel);
  const profissional = txt(b.profissional);
  const registro = txt(b.registro);

  if (!TIPOS_DE_SAIDA.includes(tipo)) return bad(res, "Selecione um tipo de saída válido.");
  if (!responsavel) return bad(res, "Informe o responsável que acompanha a criança.");
  if (!profissional || !registro) {
    return bad(res, "Informe o profissional responsável e seu registro profissional.");
  }

  // Regras específicas de cada tipo de saída.
  if (tipo === "Transferência" && !txt(b.destino)) {
    return bad(res, "Informe o serviço de destino da transferência.");
  }
  if (tipo === "Alta a pedido do responsável" && !b.termoResponsavel) {
    return bad(res, "Registre a confirmação do termo de solicitação do responsável.");
  }
  if (tipo === "Saída sem autorização (registro administrativo)" && !b.registroOcorrencia) {
    return bad(res, "Confirme o registro da ocorrência com a equipe responsável.");
  }

  const checklist = {
    identificacao: !!b.identificacao,
    documentos: !!b.documentos,
    orientacoes: !!b.orientacoes,
    pertences: !!b.pertences,
    acompanhante: !!b.acompanhante
  };
  if (Object.values(checklist).some(feito => !feito)) {
    return bad(res, "Conclua todos os itens da lista de conferência antes de registrar a saída.");
  }

  const alta = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    nascimento: paciente.nascimento,
    tipo,
    responsavel,
    profissional,
    registro,
    destino: txt(b.destino),
    contatoDestino: txt(b.contatoDestino),
    orientacoes: txt(b.orientacoesTexto),
    retorno: txt(b.retorno),
    observacoes: txt(b.observacoes),
    checklist,
    termoResponsavel: !!b.termoResponsavel,
    registroOcorrencia: !!b.registroOcorrencia,
    createdAt: new Date().toISOString()
  };

  dados.altas.push(alta);
  paciente.status = "encerrado";
  paciente.dataSaida = alta.createdAt;
  gravar(dados);

  res.status(201).json(alta);
}));

/* =====================================================
   8. ALMOXARIFADO (farmácia)
   ===================================================== */

app.get("/estoque", rota((req, res) => {
  res.json(ler().estoque);
}));

app.get("/estoque/entradas", rota((req, res) => {
  res.json(ler().entradas.slice(-15).reverse());
}));

app.post("/estoque", rota((req, res) => {
  const b = req.body;
  const nome = txt(b.nome);
  const quantidade = Number(b.qtd);

  if (!nome || !Number.isInteger(quantidade) || quantidade < 1) {
    return bad(res, "Informe o medicamento e uma quantidade inteira maior que zero.");
  }

  const dados = ler();
  let item = dados.estoque.find(i => i.nome.toLowerCase() === nome.toLowerCase());
  const ehNovo = !item;

  if (ehNovo) {
    item = {
      id: novoId(),
      nome,
      unidade: txt(b.unidade) || "unidade",
      categoria: txt(b.categoria) || "Geral",
      quantidade: 0
    };
    dados.estoque.push(item);
  }

  item.quantidade += quantidade;
  if (txt(b.validade)) item.validade = txt(b.validade);

  dados.entradas.push({
    id: novoId(),
    nome: item.nome,
    qtd: quantidade,
    tipo: ehNovo ? "novo" : "reposição",
    obs: txt(b.obs),
    createdAt: new Date()
  });

  gravar(dados);
  res.status(201).json(item);
}));

/* =====================================================
   9. CUIDADO EMOCIONAL E BEM-ESTAR
   ===================================================== */
app.use(rotasBemestar);

/* =====================================================
   INICIAR O SERVIDOR
   ===================================================== */
if (require.main === module) {
  const porta = process.env.PORT || 3000;
  app.listen(porta, () => console.log("🧸 Sentinela Pediatria em http://localhost:" + porta));
}

module.exports = app;
