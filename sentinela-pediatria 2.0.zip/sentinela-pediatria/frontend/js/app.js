/* =====================================================
   app.js — funções comuns a todas as telas

   Índice:
     1. Atalhos e ajudantes
     2. Comunicação com o servidor (api)
     3. Módulos do sistema e permissões por setor
     4. Barra lateral (guard)
     5. Avisos rápidos (toast)
     6. Componentes reutilizáveis
   ===================================================== */

/* =====================================================
   1. ATALHOS E AJUDANTES
   ===================================================== */

// $("#id") encontra um elemento; $$(".classe") encontra vários.
const $ = seletor => document.querySelector(seletor);
const $$ = seletor => [...document.querySelectorAll(seletor)];

// Protege contra HTML malicioso ao mostrar texto digitado por alguém.
function esc(valor) {
  return String(valor ?? "").replace(/[&<>"']/g, caractere => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[caractere]));
}

// Data de hoje no horário do aparelho, no formato AAAA-MM-DD.
function hojeLocal() {
  const agora = new Date();
  agora.setMinutes(agora.getMinutes() - agora.getTimezoneOffset());
  return agora.toISOString().slice(0, 10);
}

// Início do dia de hoje (usado para contar "hoje" no painel).
function inicioDoDiaISO() {
  const agora = new Date();
  agora.setHours(0, 0, 0, 0);
  return agora.toISOString();
}

// "2026-11-14T10:30:00Z" -> "14/11/2026 10:30:00"
const dataHora = iso => (iso ? new Date(iso).toLocaleString("pt-BR") : "—");

// Usuário que está logado nesta aba (ou null).
function usuarioAtual() {
  return JSON.parse(sessionStorage.getItem("u") || "null");
}

/* =====================================================
   2. COMUNICAÇÃO COM O SERVIDOR
   api("/rota")                   -> GET
   api("/rota", { dados })        -> POST
   api("/rota", { dados }, "PUT") -> outro método
   ===================================================== */
async function api(url, corpo, metodo) {
  const opcoes = {
    method: metodo || (corpo ? "POST" : "GET"),
    headers: { "Content-Type": "application/json" }
  };
  if (corpo) opcoes.body = JSON.stringify(corpo);

  let resposta;
  try {
    resposta = await fetch(url, opcoes);
  } catch {
    throw new Error("Sem conexão com o servidor.");
  }

  const dados = await resposta.json().catch(() => ({}));
  if (!resposta.ok) throw new Error(dados.erro || "Erro " + resposta.status);
  return dados;
}

/* =====================================================
   3. MÓDULOS DO SISTEMA E PERMISSÕES POR SETOR

   Para criar uma tela nova no menu:
     1. adicione uma linha em MODULOS;
     2. liste a chave nos setores que podem vê-la em ACESSO.
   ===================================================== */

// Ordem em que os grupos aparecem na barra lateral.
const GRUPOS = [
  "Atendimento",
  "Cuidado emocional",
  "Bem-estar da criança",
  "Apoio",
  "Gestão"
];

const MODULOS = {
  atendimento:  { arquivo: "atendimento.html",  rotulo: "Recepção",            icone: "🧾", grupo: "Atendimento" },
  triagem:      { arquivo: "triagem.html",      rotulo: "Triagem",             icone: "🩺", grupo: "Atendimento" },
  medico:       { arquivo: "medico.html",       rotulo: "Pediatra",            icone: "👩‍⚕️", grupo: "Atendimento" },
  medicacoes:   { arquivo: "medicacoes.html",   rotulo: "Prescrições",         icone: "📋", grupo: "Atendimento" },
  altas:        { arquivo: "altas.html",        rotulo: "Altas",               icone: "🏥", grupo: "Atendimento" },

  psicologia:   { arquivo: "psicologia.html",   rotulo: "Psicologia",          icone: "💬", grupo: "Cuidado emocional" },
  psiquiatria:  { arquivo: "psiquiatria.html",  rotulo: "Psiquiatria infantil", icone: "🧠", grupo: "Cuidado emocional" },

  bemestar:     { arquivo: "bemestar.html",     rotulo: "Espaço bem-estar",    icone: "🎨", grupo: "Bem-estar da criança" },
  criancas:     { arquivo: "criancas.html",     rotulo: "Cantinho da criança", icone: "🌈", grupo: "Bem-estar da criança" },

  almoxarifado: { arquivo: "almoxarifado.html", rotulo: "Farmácia",            icone: "📦", grupo: "Apoio" },

  admin:        { arquivo: "admin.html",        rotulo: "Visão geral",         icone: "📊", grupo: "Gestão" },
  usuarios:     { arquivo: "usuarios.html",     rotulo: "Usuários",            icone: "👥", grupo: "Gestão" },
  tv:           { arquivo: "tv.html",           rotulo: "Painel da TV",        icone: "📺", grupo: "Gestão", externo: true }
};

// Nome de cada setor (perfil de usuário) em português.
const SETORES = {
  atendimento:  "Atendimento (recepção)",
  triagem:      "Triagem",
  medico:       "Pediatra",
  psicologia:   "Psicologia",
  psiquiatria:  "Psiquiatria infantil",
  bemestar:     "Equipe de bem-estar",
  almoxarifado: "Farmácia / Almoxarifado",
  admin:        "Administrador"
};

// Quais telas cada setor pode abrir.
// A primeira da lista é a tela inicial do setor.
const ACESSO = {
  atendimento:  ["atendimento"],
  triagem:      ["triagem"],
  medico:       ["medico", "medicacoes", "altas", "bemestar", "criancas"],
  psicologia:   ["psicologia", "bemestar", "criancas"],
  psiquiatria:  ["psiquiatria", "psicologia", "bemestar", "criancas"],
  bemestar:     ["bemestar", "criancas"],
  almoxarifado: ["almoxarifado", "medicacoes"],
  admin:        ["admin", ...Object.keys(MODULOS).filter(chave => chave !== "admin")]
};

// Tela inicial de cada setor (usada logo após o login).
const HOME = Object.fromEntries(
  Object.entries(ACESSO).map(([setor, telas]) => [setor, MODULOS[telas[0]].arquivo])
);

/* =====================================================
   4. BARRA LATERAL
   Cada tela chama guard("nome-da-tela") no começo do script.
   Se a pessoa não estiver logada (ou não tiver permissão),
   volta para o login. Senão, monta o menu e o topo.
   ===================================================== */
function guard(pagina) {
  const usuario = usuarioAtual();
  const permitidas = usuario ? ACESSO[usuario.tipo] || [] : [];

  if (!usuario || !permitidas.includes(pagina)) {
    location.href = "index.html";
    return;
  }

  montarLayout(pagina, usuario, permitidas);
}

// Monta uma seção do menu (título do grupo + links).
function htmlGrupoMenu(nomeGrupo, pagina, permitidas) {
  const links = permitidas
    .filter(chave => MODULOS[chave].grupo === nomeGrupo)
    .map(chave => {
      const modulo = MODULOS[chave];
      const atual = chave === pagina;
      const abrirEmNovaAba = modulo.externo ? ' target="_blank" rel="noopener"' : "";
      const marcarAtual = atual ? ' aria-current="page"' : "";

      return `
        <a class="menu-link${atual ? " on" : ""}" href="${modulo.arquivo}"${abrirEmNovaAba}${marcarAtual}>
          <span class="menu-icone" aria-hidden="true">${modulo.icone}</span>
          ${modulo.rotulo}${modulo.externo ? " ↗" : ""}
        </a>`;
    });

  if (!links.length) return "";

  return `
    <div class="menu-grupo">
      <p class="menu-titulo">${nomeGrupo}</p>
      ${links.join("")}
    </div>`;
}

function montarLayout(pagina, usuario, permitidas) {
  const conteudo = document.querySelector(".container");
  const modulo = MODULOS[pagina];

  document.title = modulo.rotulo + " - Sentinela Pediatria";

  const menuGrupos = GRUPOS
    .map(nome => htmlGrupoMenu(nome, pagina, permitidas))
    .join("");

  const estrutura = document.createElement("div");
  estrutura.className = "shell";
  estrutura.innerHTML = `
    <aside class="menu" id="menu" aria-label="Menu principal">
      <a class="menu-marca" href="${HOME[usuario.tipo]}">
        🧸 <span>Sentinela<br>Pediatria</span>
      </a>

      <nav>${menuGrupos}</nav>

      <div class="menu-rodape">
        <div class="menu-usuario">
          <b>${esc(usuario.usuario)}</b>
          <small>${esc(SETORES[usuario.tipo] || usuario.tipo)}</small>
        </div>
        <a href="#" id="sair" class="menu-link">
          <span class="menu-icone" aria-hidden="true">🚪</span> Sair
        </a>
      </div>
    </aside>

    <div class="menu-fundo" id="menuFundo"></div>

    <div class="principal">
      <header class="topo">
        <button type="button" class="btn-menu" id="btnMenu"
                aria-label="Abrir menu" aria-controls="menu" aria-expanded="false">☰</button>
        <p class="topo-titulo">${modulo.icone} ${modulo.rotulo}</p>
      </header>
    </div>`;

  document.body.prepend(estrutura);
  estrutura.querySelector(".principal").append(conteudo);

  ligarEventosDoMenu();
}

function ligarEventosDoMenu() {
  const botao = $("#btnMenu");

  const abrirOuFechar = abrir => {
    document.body.classList.toggle("menu-aberto", abrir);
    botao.setAttribute("aria-expanded", String(abrir));
  };

  botao.onclick = () => abrirOuFechar(!document.body.classList.contains("menu-aberto"));
  $("#menuFundo").onclick = () => abrirOuFechar(false);
  addEventListener("keydown", evento => {
    if (evento.key === "Escape") abrirOuFechar(false);
  });

  $("#sair").onclick = evento => {
    evento.preventDefault();
    sessionStorage.removeItem("u");
    location.href = "index.html";
  };
}

/* =====================================================
   5. AVISOS RÁPIDOS
   toast("Salvo!")          -> aviso normal
   toast("Deu erro", true)  -> aviso vermelho
   ===================================================== */
function toast(mensagem, erro) {
  const aviso = document.createElement("div");
  aviso.className = "toast" + (erro ? " err" : "");
  aviso.textContent = mensagem;
  aviso.setAttribute("role", "status");
  document.body.append(aviso);

  setTimeout(() => aviso.remove(), 3500);
}

/* =====================================================
   6. COMPONENTES REUTILIZÁVEIS
   ===================================================== */

// Cria as carinhas de humor dentro de um elemento.
// Devolve { valor(), limpar() }. Clicar de novo na mesma carinha desmarca.
//   const humor = seletorHumor($("#meuHumor"), valor => console.log(valor));
function seletorHumor(container, aoEscolher) {
  let escolhido = null;

  container.classList.add("humor-opcoes");
  container.innerHTML = Bemestar.HUMORES.map(h => `
    <button type="button" class="humor-btn" data-valor="${h.valor}" aria-pressed="false">
      <span class="humor-emoji" aria-hidden="true">${h.emoji}</span>
      <small>${esc(h.rotulo)}</small>
    </button>`).join("");

  const atualizarBotoes = () => {
    container.querySelectorAll(".humor-btn").forEach(botao => {
      const marcado = Number(botao.dataset.valor) === escolhido;
      botao.setAttribute("aria-pressed", String(marcado));
    });
  };

  container.onclick = evento => {
    const botao = evento.target.closest(".humor-btn");
    if (!botao) return;

    const valor = Number(botao.dataset.valor);
    escolhido = escolhido === valor ? null : valor;
    atualizarBotoes();

    if (aoEscolher) aoEscolher(escolhido);
  };

  return {
    valor: () => escolhido,
    limpar() {
      escolhido = null;
      atualizarBotoes();
    }
  };
}

// Monta as <option> de um <select> com as crianças.
function opcoesPacientes(lista, textoInicial) {
  const inicial = `<option value="">${esc(textoInicial)}</option>`;
  const opcoes = lista.map(p =>
    `<option value="${p.id}">${esc(p.nome)} · ${esc(p.idadeTexto)}</option>`
  );
  return inicial + opcoes.join("");
}

// Emoji + texto do humor (ex.: "😄 Muito feliz"), ou "—" se vazio.
function rotuloHumor(valor) {
  const humor = Bemestar.humorPorValor(valor);
  return humor ? humor.emoji + " " + humor.rotulo : "—";
}

// Nome amigável da urgência de um encaminhamento.
function rotuloUrgencia(id) {
  const urgencia = Bemestar.URGENCIAS.find(u => u.id === id);
  return urgencia ? urgencia.nome : id;
}
