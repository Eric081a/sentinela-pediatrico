/* =====================================================
   bemestar.js — listas e escalas do cuidado emocional.
   Usado pelo servidor (validação) e pelo navegador (telas).
   ATENÇÃO: conteúdo de apoio/demonstração. Os critérios
   clínicos devem seguir o protocolo do hospital.
   ===================================================== */

(function (raiz, fabrica) {
  if (typeof module === "object" && module.exports) {
    module.exports = fabrica();
  } else {
    raiz.Bemestar = fabrica();
  }
})(this, function () {

  /* ---------- Como a criança está se sentindo (1 a 5) ---------- */
  const HUMORES = [
    { valor: 1, emoji: "😢", rotulo: "Muito triste" },
    { valor: 2, emoji: "😕", rotulo: "Triste" },
    { valor: 3, emoji: "😐", rotulo: "Mais ou menos" },
    { valor: 4, emoji: "🙂", rotulo: "Bem" },
    { valor: 5, emoji: "😄", rotulo: "Muito feliz" }
  ];

  /* ---------- Escala de dor com carinhas (0 a 10) ---------- */
  const FACES_DOR = [
    { valor: 0,  emoji: "😀", rotulo: "Sem dor" },
    { valor: 2,  emoji: "🙂", rotulo: "Um pouquinho" },
    { valor: 4,  emoji: "😐", rotulo: "Dói um pouco" },
    { valor: 6,  emoji: "😟", rotulo: "Dói bastante" },
    { valor: 8,  emoji: "😣", rotulo: "Dói muito" },
    { valor: 10, emoji: "😭", rotulo: "A pior dor" }
  ];

  /* ---------- Atividades que ajudam a criança a se sentir melhor ---------- */
  const ATIVIDADES = [
    {
      id: "brinquedoteca", nome: "Brinquedoteca", icone: "🧸",
      descricao: "Espaço para brincar livremente com jogos e brinquedos, acompanhado por um profissional.",
      indicado: "Todas as idades", duracao: "30 a 60 min"
    },
    {
      id: "sala-sensorial", nome: "Sala sensorial", icone: "✨",
      descricao: "Ambiente com luz suave, sons e texturas para acalmar e reduzir a ansiedade.",
      indicado: "Crianças ansiosas ou agitadas", duracao: "20 a 40 min"
    },
    {
      id: "arteterapia", nome: "Arteterapia", icone: "🎨",
      descricao: "Desenho, pintura e colagem para a criança expressar o que sente.",
      indicado: "A partir de 3 anos", duracao: "40 min"
    },
    {
      id: "musicoterapia", nome: "Musicoterapia", icone: "🎵",
      descricao: "Cantar, tocar e ouvir música para relaxar e se conectar com os outros.",
      indicado: "Todas as idades", duracao: "30 min"
    },
    {
      id: "contacao", nome: "Contação de histórias", icone: "📚",
      descricao: "Histórias, fantoches e leitura em voz alta, no leito ou na brinquedoteca.",
      indicado: "Todas as idades", duracao: "20 a 30 min"
    },
    {
      id: "classe-hospitalar", nome: "Classe hospitalar", icone: "✏️",
      descricao: "Apoio pedagógico para a criança não perder o ritmo escolar.",
      indicado: "Idade escolar", duracao: "40 a 60 min"
    },
    {
      id: "terapia-ocupacional", nome: "Terapia ocupacional", icone: "🧩",
      descricao: "Atividades para manter autonomia, coordenação e rotina durante o tratamento.",
      indicado: "Conforme avaliação da equipe", duracao: "30 a 45 min"
    },
    {
      id: "alegria", nome: "Visita da alegria", icone: "🎈",
      descricao: "Palhaços, voluntários e artistas que levam diversão aos leitos e à espera.",
      indicado: "Todas as idades", duracao: "15 a 30 min"
    },
    {
      id: "pet-terapia", nome: "Pet terapia", icone: "🐶",
      descricao: "Visita de cães de terapia, somente com autorização da comissão de controle de infecção.",
      indicado: "Conforme protocolo do hospital", duracao: "15 a 20 min"
    },
    {
      id: "relaxamento", nome: "Relaxamento e respiração", icone: "🌬️",
      descricao: "Exercícios guiados de respiração e calma, antes de exames e procedimentos.",
      indicado: "A partir de 4 anos", duracao: "10 a 15 min"
    }
  ];

  /* ---------- Psicologia ---------- */
  const TIPOS_SESSAO = [
    { id: "acolhimento", nome: "Acolhimento inicial" },
    { id: "escuta", nome: "Escuta e suporte emocional" },
    { id: "preparo", nome: "Preparo para exame ou procedimento" },
    { id: "brincar", nome: "Brincar terapêutico" },
    { id: "familia", nome: "Orientação à família" },
    { id: "dificil", nome: "Apoio em situação difícil (perda, notícia difícil)" }
  ];

  const TECNICAS = [
    { id: "escuta-ativa", nome: "Escuta ativa" },
    { id: "brincar", nome: "Brincar terapêutico" },
    { id: "desenho", nome: "Desenho / arte" },
    { id: "respiracao", nome: "Respiração e relaxamento" },
    { id: "psicoeducacao", nome: "Psicoeducação (criança/família)" },
    { id: "historias", nome: "Histórias e fantoches" }
  ];

  /* ---------- Psiquiatria infantil ---------- */
  // "critico: true" = sinal que exige atenção imediata da equipe.
  const SINAIS_PSIQUIATRIA = [
    { id: "ansiedade", nome: "Ansiedade intensa / medo persistente" },
    { id: "agitacao", nome: "Agitação psicomotora" },
    { id: "sono", nome: "Alteração importante do sono" },
    { id: "apetite", nome: "Alteração importante do apetite" },
    { id: "tristeza", nome: "Tristeza persistente / choro frequente" },
    { id: "isolamento", nome: "Isolamento / recusa de contato" },
    { id: "regressao", nome: "Regressão de comportamento" },
    { id: "irritabilidade", nome: "Irritabilidade / agressividade" },
    { id: "ideacao", nome: "Fala sobre morte ou sobre se machucar", critico: true },
    { id: "automutilacao", nome: "Lesões autoprovocadas / histórico de automutilação", critico: true },
    { id: "alucinacao", nome: "Alucinações ou confusão mental", critico: true }
  ];

  const CONDUTAS_PSIQUIATRIA = [
    "Orientação à família e acompanhamento pela psicologia",
    "Observação e nova avaliação durante o atendimento",
    "Acompanhamento ambulatorial em psiquiatria infantil",
    "Encaminhamento para serviço especializado (ex.: CAPSi)",
    "Discussão do caso com a equipe multiprofissional"
  ];

  const RISCOS = ["baixo", "moderado", "alto"];

  /* ---------- Encaminhamentos ---------- */
  const URGENCIAS = [
    { id: "rotina", nome: "Rotina" },
    { id: "prioritaria", nome: "Prioritária" },
    { id: "urgente", nome: "Urgente" }
  ];

  const DESTINOS = ["psicologia", "psiquiatria"];

  /* ---------- Funções de apoio ---------- */
  const humorPorValor = valor => HUMORES.find(h => h.valor === valor) || null;

  // Para dor, devolve a carinha mais próxima do valor (ex.: 7 -> 8).
  function facePorDor(valor) {
    return FACES_DOR.reduce((melhor, face) =>
      Math.abs(face.valor - valor) < Math.abs(melhor.valor - valor) ? face : melhor
    );
  }

  return {
    HUMORES, FACES_DOR, ATIVIDADES,
    TIPOS_SESSAO, TECNICAS,
    SINAIS_PSIQUIATRIA, CONDUTAS_PSIQUIATRIA, RISCOS,
    URGENCIAS, DESTINOS,
    humorPorValor, facePorDor
  };
});
