# 🧸 Sentinela Pediatria

Sistema hospitalar pediátrico: recepção, triagem, pediatra, altas, farmácia, painel de TV
e agora **cuidado emocional e bem-estar da criança**.

## Como rodar

```bash
npm install
npm start
# abre em http://localhost:3000
```

## Usuários de exemplo

| Usuário        | Senha      | Setor                  |
|----------------|------------|------------------------|
| admin          | admin123   | Administrador          |
| atendimento    | 123        | Recepção               |
| triagem        | 123        | Triagem                |
| medico         | 123        | Pediatra               |
| almoxarifado   | 123        | Farmácia               |
| psicologia     | 123        | Psicologia (novo)      |
| psiquiatria    | 123        | Psiquiatria (novo)     |
| bemestar       | 123        | Equipe de bem-estar (novo) |

> ⚠️ Troque todas as senhas antes de usar fora de testes (tela **Usuários**).

## Estrutura

```
backend/
  server.js           rotas do hospital (login, recepção, triagem, consulta, alta, farmácia)
  rotas-bemestar.js   rotas novas (psicologia, psiquiatria, humor, atividades, resumo)
  banco.js            leitura/gravação do db.json e senhas
  util.js             funções pequenas de apoio
  db.json             dados

frontend/
  index.html          login
  admin.html          visão geral do administrador
  usuarios.html       cadastro e edição de usuários
  atendimento.html, triagem.html, medico.html, medicacoes.html, altas.html, almoxarifado.html
  psicologia.html     NOVO · sessões e pedidos de atendimento
  psiquiatria.html    NOVO · avaliações de psiquiatria infantil
  bemestar.html       NOVO · brinquedoteca, arte, música... com agenda
  criancas.html       NOVO · cantinho da criança (humor, dor, respiração, jogo)
  tv.html             painel de chamada
  css/style.css       visual
  js/app.js           menu lateral, permissões e funções comuns
  js/pediatria.js     regras clínicas (risco, doses)
  js/bemestar.js      escalas e catálogos do cuidado emocional
```

## Como adicionar uma tela nova ao menu

1. Crie o `.html` (copie uma tela existente; ela começa com `guard("nome")`).
2. Em `frontend/js/app.js`, acrescente uma linha em **`MODULOS`**.
3. Coloque o nome da tela em **`ACESSO`**, nos setores que podem vê-la.

O menu lateral se ajusta sozinho (e vira gaveta no celular).

## Para editar as listas do cuidado emocional

Atividades, sinais, técnicas e escalas ficam todas em `frontend/js/bemestar.js`.

## Avisos importantes

- Conteúdo clínico (classificação, doses, sinais, condutas) é **apoio/demonstração** e deve ser
  validado pelos protocolos do hospital.
- A API **ainda não exige login por requisição**: quem conhecer o endereço consegue chamar as rotas.
  Antes de usar com dados reais (principalmente psicologia/psiquiatria), adicione autenticação (ex.: token/JWT).
- Na Vercel o `db.json` fica em `/tmp` e é apagado de tempos em tempos. Para uso real, use um banco de dados.
